This ZIP archive contains my final report, presentation slides, source code, and an example report card output from my program.

Please refer to the following GitHub repository for information regarding packages used in the code, source code, and the example report card output.

Some packages used in this program are not pre-installed by Python. 
Please run the commands below if you run into missing packes errors.

python3 -m pip install --upgrade pip
python3 -m pip install tabulate requests matplotlib